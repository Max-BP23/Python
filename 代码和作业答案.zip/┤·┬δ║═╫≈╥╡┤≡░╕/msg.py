def send_email():
    pass


def send_message():
    pass


def send_wechat():
    pass
