def int_to_string():
    pass


def gb_to_mb():
    pass


def int_to_float():
    pass
