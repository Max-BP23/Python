from src.handler import handler

if __name__ == '__main__':
    handler.run()
